#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include "towerposition.h"
#include "tower.h"
#include "tower1.h"
#include "tower2.h"

namespace Ui {
class MainWindow;
}

class WayPoint;
class Enemy;
class Bullet;

class MainWindow : public QMainWindow
{
	Q_OBJECT
	
public:
	explicit MainWindow(QWidget *parent = 0);
	~MainWindow();

	void getHpDamage(int damage = 1);
	void removedEnemy(Enemy *enemy);
	void removedBullet(Bullet *bullet);
	void addBullet(Bullet *bullet);
	void awardGold(int gold);

    QList<Enemy *> enemyList() const;

protected:
	void paintEvent(QPaintEvent *);
	void mousePressEvent(QMouseEvent *);
    void mouseDoubleClickEvent(QMouseEvent *);

private slots:
	void updateMap();
	void gameStart();

private:
	void loadTowerPositions();
	void addWayPoints();
	bool loadWave();
	bool canBuyTower() const;
    bool canBuyTower1() const;
    bool canBuyTower2() const;
	void drawWave(QPainter *painter);
	void drawHP(QPainter *painter);
	void drawPlayerGold(QPainter *painter);
	void doGameOver();
	void preLoadWavesInfo();

private:
	Ui::MainWindow *		ui;
	int						m_waves;
    int						m_playerHp;//玩家生命值
    int						m_playrGold;//金币
	bool					m_gameEnded;
    bool					m_gameWin;
	QList<QVariant>			m_wavesInfo;
	QList<TowerPosition>	m_towerPositionsList;
    QList<Tower *>			m_towersList;
    QList<Tower1 *>			m_towers1List;
    QList<Tower2 *>			m_towers2List;
	QList<WayPoint *>		m_wayPointsList;
	QList<Enemy *>			m_enemyList;
    QList<Bullet *>			m_bulletList;
};

#endif // MAINWINDOW_H
