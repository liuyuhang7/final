#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>

class WayPoint;
class QPainter;
class MainWindow;
class Tower;
class Tower1;
class Tower2;

class Enemy : public QObject
{
	Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/enemy2.png"));
	~Enemy();

	void draw(QPainter *painter) const;
	void move();
	void getDamage(int damage);
	void getRemoved();
	void getAttacked(Tower *attacker);
	void gotLostSight(Tower *attacker);
    void getAttacked1(Tower1 *attacker);
    void gotLostSight1(Tower1 *attacker);
    void getAttacked2(Tower2 *attacker);
    void gotLostSight2(Tower2 *attacker);
	QPoint pos() const;

public slots:
	void doActivate();

private:
    bool m_active;
    int m_maxHp;//满血
    int m_currentHp;//现在的血
    qreal m_walkingSpeed;

    QPoint m_pos;
    WayPoint * m_destinationWayPoint;
    MainWindow * m_game;
    QList<Tower *> m_attackedTowersList;
    QList<Tower1 *>	m_attackedTowers1List;
    QList<Tower2 *>	m_attackedTowers2List;

	const QPixmap	m_sprite;
	static const QSize ms_fixedSize;
};

#endif // ENEMY_H
