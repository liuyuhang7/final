#include "startwindow.h"
#include "mainwindow.h"
#include "button.h"
#include <QPainter>
#include <QPixmap>
#include <QPushButton>


startwindow::startwindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(800,600);
    Button * bin = new Button(":/image/button.png");
    bin->setParent(this);
    bin->move(150,350);
    MainWindow * mainwindow = new MainWindow;
    connect(bin,&QPushButton::clicked,this,[=](){
        this->close();
        mainwindow->show();
    });
}

void startwindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/image/start.gif");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
