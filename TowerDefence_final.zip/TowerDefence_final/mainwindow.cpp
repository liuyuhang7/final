#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "waypoint.h"
#include "enemy.h"
#include "bullet.h"
#include "plistreader.h"
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtDebug>

static const int TowerCost = 200;
static const int Tower1Cost = 400;
static const int Tower2Cost = 600;

MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
	, ui(new Ui::MainWindow)
	, m_waves(0)
    , m_playerHp(3)
    , m_playrGold(600)//初始金币
	, m_gameEnded(false)
	, m_gameWin(false)
{
	ui->setupUi(this);

	preLoadWavesInfo();
	loadTowerPositions();
	addWayPoints();

	QTimer *timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
	timer->start(30);

    // 设置10s后游戏启动
    QTimer::singleShot(10000, this, SLOT(gameStart()));
}

MainWindow::~MainWindow()
{
	delete ui;
}

void MainWindow::loadTowerPositions()//塔的位置
{
    QFile file(":/config/TowersPosition.plist");
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, "TowerDefense", "Cannot Open TowersPosition.plist");
        return;
    }

    PListReader reader;
    reader.read(&file);

    QList<QVariant> array = reader.data();
    foreach (QVariant dict, array)
    {
        QMap<QString, QVariant> point = dict.toMap();
        int x = point.value("x").toInt();
        int y = point.value("y").toInt();
        m_towerPositionsList.push_back(QPoint(x, y));
    }

    file.close();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    if (m_gameEnded || m_gameWin)//画结束界面图
	{
        QPixmap win(":/image/win.gif");
        QPixmap end(":/image/end.gif");
        QPixmap pixmap = m_gameEnded ? end : win;
        QPainter painter(this);
        painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
		return;
	}

    QPixmap cachePix(":/image/background.jpg");
	QPainter cachePainter(&cachePix);

	foreach (const TowerPosition &towerPos, m_towerPositionsList)
		towerPos.draw(&cachePainter);

    foreach (const Tower *tower, m_towersList)
		tower->draw(&cachePainter);

    foreach (const Tower1 *tower1, m_towers1List)
        tower1->draw(&cachePainter);

    foreach (const Tower2 *tower2, m_towers2List)
        tower2->draw(&cachePainter);

	foreach (const WayPoint *wayPoint, m_wayPointsList)
		wayPoint->draw(&cachePainter);

	foreach (const Enemy *enemy, m_enemyList)
		enemy->draw(&cachePainter);

	foreach (const Bullet *bullet, m_bulletList)
		bullet->draw(&cachePainter);

	drawWave(&cachePainter);
	drawHP(&cachePainter);
	drawPlayerGold(&cachePainter);

	QPainter painter(this);
    painter.drawPixmap(0, 0, cachePix);
}

//点击放塔
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)//左键单击时放tower
    {
        QPoint pressPos = event->pos();
        auto it = m_towerPositionsList.begin();
        while (it != m_towerPositionsList.end())
        {
            if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower())
            {
                m_playrGold -= TowerCost;
                it->setHasTower();

                Tower *tower = new Tower(it->centerPos(), this);
                m_towersList.push_back(tower);
                update();
                break;
            }
            ++it;
        }
    }
    if (event->button() == Qt::RightButton)//右键单击时放tower1
    {
        QPoint pressPos = event->pos();
        auto it = m_towerPositionsList.begin();
        while (it != m_towerPositionsList.end())
        {
            if (canBuyTower1() && it->containPoint(pressPos) && !it->hasTower())
            {
                m_playrGold -= Tower1Cost;
                it->setHasTower();

                Tower1 *tower1 = new Tower1(it->centerPos(), this);
                m_towers1List.push_back(tower1);
                update();
                break;
            }
            ++it;
        }
    }
}
//双击时放tower2
void MainWindow::mouseDoubleClickEvent(QMouseEvent*event){
    QPoint pressPos = event->pos();
    auto it = m_towerPositionsList.begin();
    while (it != m_towerPositionsList.end())
    {
        if (canBuyTower2() && it->containPoint(pressPos) && !it->hasTower())
        {
            m_playrGold -= Tower2Cost;
            it->setHasTower();

            Tower2 *tower2 = new Tower2(it->centerPos(), this);
            m_towers2List.push_back(tower2);
            update();
            break;
        }
        ++it;
    }
}

//买塔
bool MainWindow::canBuyTower() const
{
    if (m_playrGold >= TowerCost)
		return true;
	return false;
}
bool MainWindow::canBuyTower1() const
{
    if (m_playrGold >= Tower1Cost)
        return true;
    return false;
}
bool MainWindow::canBuyTower2() const
{
    if (m_playrGold >= Tower2Cost)
        return true;
    return false;
}


void MainWindow::drawWave(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(400, 5, 100, 25), QString("WAVE : %1").arg(m_waves + 1));
}

void MainWindow::drawHP(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
	painter->drawText(QRect(30, 5, 100, 25), QString("HP : %1").arg(m_playerHp));
}

void MainWindow::drawPlayerGold(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
	painter->drawText(QRect(200, 5, 200, 25), QString("GOLD : %1").arg(m_playrGold));
}

void MainWindow::doGameOver()
{
	if (!m_gameEnded)
	{
		m_gameEnded = true;
        // 此处应该切换场景到结束场景
	}
}

void MainWindow::awardGold(int gold)
{
	m_playrGold += gold;
	update();
}

//航点
void MainWindow::addWayPoints()
{
    WayPoint *wayPoint1 = new WayPoint(QPoint(130,560));
    m_wayPointsList.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(130,320));
    m_wayPointsList.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    WayPoint *wayPoint3 = new WayPoint(QPoint(630,320));
    m_wayPointsList.push_back(wayPoint3);
    wayPoint3->setNextWayPoint(wayPoint2);

    WayPoint *wayPoint4 = new WayPoint(QPoint(630,130));
    m_wayPointsList.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint5 = new WayPoint(QPoint(35,130));
    m_wayPointsList.push_back(wayPoint5);
    wayPoint5->setNextWayPoint(wayPoint4);

}

//生命值受损
void MainWindow::getHpDamage(int damage)
{
	m_playerHp -= damage;
	if (m_playerHp <= 0)
		doGameOver();
}

void MainWindow::removedEnemy(Enemy *enemy)
{
	Q_ASSERT(enemy);

	m_enemyList.removeOne(enemy);
	delete enemy;

	if (m_enemyList.empty())
	{
		++m_waves;
		if (!loadWave())
		{
			m_gameWin = true;
            // 游戏胜利转到游戏胜利场景
		}
	}
}

void MainWindow::removedBullet(Bullet *bullet)
{
	Q_ASSERT(bullet);

	m_bulletList.removeOne(bullet);
	delete bullet;
}

void MainWindow::addBullet(Bullet *bullet)
{
	Q_ASSERT(bullet);

	m_bulletList.push_back(bullet);
}

void MainWindow::updateMap()
{
	foreach (Enemy *enemy, m_enemyList)
		enemy->move();
    foreach (Tower *tower, m_towersList)
        tower->checkEnemyInRange();
    foreach (Tower1 *tower1, m_towers1List)
        tower1->checkEnemyInRange();
    foreach (Tower2 *tower2, m_towers2List)
        tower2->checkEnemyInRange();
	update();
}

//预读波数信息
void MainWindow::preLoadWavesInfo()
{
	QFile file(":/config/Waves.plist");
	if (!file.open(QFile::ReadOnly | QFile::Text))
	{
		QMessageBox::warning(this, "TowerDefense", "Cannot Open TowersPosition.plist");
		return;
	}

	PListReader reader;
	reader.read(&file);

	// 获取波数信息
	m_wavesInfo = reader.data();

	file.close();
}

bool MainWindow::loadWave()
{
	if (m_waves >= m_wavesInfo.size())
		return false;

	WayPoint *startWayPoint = m_wayPointsList.back();
	QList<QVariant> curWavesInfo = m_wavesInfo[m_waves].toList();

	for (int i = 0; i < curWavesInfo.size(); ++i)
	{
		QMap<QString, QVariant> dict = curWavesInfo[i].toMap();
		int spawnTime = dict.value("spawnTime").toInt();

		Enemy *enemy = new Enemy(startWayPoint, this);
		m_enemyList.push_back(enemy);
		QTimer::singleShot(spawnTime, enemy, SLOT(doActivate()));
	}

	return true;
}

QList<Enemy *> MainWindow::enemyList() const
{
	return m_enemyList;
}

void MainWindow::gameStart()
{
	loadWave();
}
