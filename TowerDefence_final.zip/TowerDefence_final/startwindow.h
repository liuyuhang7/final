#ifndef STARTWINDOW_H
#define STARTWINDOW_H

#include <QMainWindow>


class startwindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit startwindow(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *);

};

#endif // STARTWINDOW_H
